//
//  DetailViewController.m
//  ASKVIDER
//
//  Created by NM001 on 9/7/19.
//  Copyright © 2019 Suhaib IT. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    NSString *url=[[[[[_newsData valueForKey:@"media"]objectAtIndex:0]valueForKey:@"media-metadata"]objectAtIndex:0]valueForKey:@"url"];
    
    NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:url]];
    _imageview.image = [UIImage imageWithData:imageData];
    
    _textview.text=[_newsData valueForKey:@"abstract"];
    _tittleLabel.text=[_newsData valueForKey:@"title"];
    // Do any additional setup after loading the view.
}
- (IBAction)backClick:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
