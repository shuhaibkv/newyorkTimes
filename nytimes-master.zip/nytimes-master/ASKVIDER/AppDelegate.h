//
//  AppDelegate.h
//  ASKVIDER
//
//  Created by Suhaib IT on 9/7/19.
//  Copyright © 2019 Suhaib IT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

