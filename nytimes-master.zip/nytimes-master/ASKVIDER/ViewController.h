//
//  ViewController.h
//  ASKVIDER
//
//  //  Created by Suhaib IT on 9/7/19.
//  Copyright © 2019 Suhaib IT. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *tableView;


@end

