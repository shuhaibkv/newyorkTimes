//
//  DetailViewController.h
//  ASKVIDER
//
//  Created by NM001 on 9/7/19.
//  Copyright © 2019 Suhaib IT. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface DetailViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *imageview;
@property (weak, nonatomic) IBOutlet UITextView *textview;
@property (weak, nonatomic) IBOutlet UILabel *tittleLabel;
@property (weak, nonatomic) NSMutableArray *newsData;

@end

NS_ASSUME_NONNULL_END
